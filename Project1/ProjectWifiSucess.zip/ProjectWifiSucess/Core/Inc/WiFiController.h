#ifndef _WIFI_CONTROLLER_H_
#define _WIFI_CONTROLLER_H_

void WiFiControllerISR(void);
int WiFi_Controller_Init(void);

#endif //_WIFI_CONTROLLER_H_
